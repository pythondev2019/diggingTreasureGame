name = 'diggingTreasureGame'
