import doctest

doctest.testfile("tests.txt")
