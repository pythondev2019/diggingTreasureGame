name = "diggingTreasureGame"
