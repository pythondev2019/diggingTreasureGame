name = "diggingTreasureGame"

from .main import *